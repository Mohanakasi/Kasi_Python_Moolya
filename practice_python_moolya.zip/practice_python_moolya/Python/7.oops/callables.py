class temp:
    def __call__(self):
        pass

c = temp()
