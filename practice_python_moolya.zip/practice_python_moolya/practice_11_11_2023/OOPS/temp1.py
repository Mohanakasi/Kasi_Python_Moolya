from temp2 import Car
# from abc import ABC, abstractmethod
class bike(Car):

    @abs
    def mileage(self):
        print("bike also has milage")

    def engine(self):
        super().engine()
        print("bike enfingf")