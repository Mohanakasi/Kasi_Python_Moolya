def add_(a: int, b: int) -> 10:
    print(a + b)


print(add_(1, 2))
print(add_("a", "b"))