import pickle
data = 'kasi'
with open("legend.pkl",'wb') as