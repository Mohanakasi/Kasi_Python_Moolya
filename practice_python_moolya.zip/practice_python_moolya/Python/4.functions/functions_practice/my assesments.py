# num = 7
# count = 0
# def prime_check(num):
#     for i in range(2,num):
#         if num % i == 0:
#             return False
#     else:
#         return True
# while num > 0:
#     if prime_check(num) == True and count == 0:
#         print(f"the given number {num} is a prime")
#         break
#     else:
#         num += 1
#         count += 1
#         if prime_check(num) == True and count > 0:
#             print("the next number of give number is a prime","----->", num)
#             break

# string_ = '123456789'
# for i in range(len(string_)):
#     if i == 0 or i == len(string_)-1:
#         print(string_[i])
#     else:
#         print(string_[(len(string_) // 2) - 1 : (len(string_) // 2)+1])


