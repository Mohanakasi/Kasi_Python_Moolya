#we can not use same type of qoutes with in the string to define a string inside a string

#string indexes


#inbuilt methods
"upper()"
"find()"
"count()"
"strip()"
"split()"
"replace()"


#string literals
