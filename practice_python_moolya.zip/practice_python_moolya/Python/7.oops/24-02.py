"encapsulation"

