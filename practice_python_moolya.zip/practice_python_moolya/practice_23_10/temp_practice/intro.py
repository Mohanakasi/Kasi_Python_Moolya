import keyword
print(keyword.kwlist)
print(type(keyword.kwlist))
print(keyword.iskeyword('is'))

#define a variable
var_name = 'Kasi'

#type function
print(type('Mohana'))

#memory check
"id()"
a = 'kasi'
a = 'Mohana'
"even the value of a is overided, the variable name will be the same"
"But the memory id's will be different bcoz python interpretor will consider as new variable"

var1, var2, var3 = 1009, 'kasi', (1,2,3)
print(var1, var2, var3)

#and, or


#identity check of variables
a = 10
b =20
print(a is b)
print(a is not b)

#value check
print(a == b)

#Exponential
a = 5
b = 5
print(a ** b)

#bodmas rules
"order of bodmas"
#brackets
#order of powers
#divison
#multiplication
#adition
#substraction



