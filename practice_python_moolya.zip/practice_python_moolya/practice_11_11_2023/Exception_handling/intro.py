try:
    print(len(20))
except TypeError:
    print('We can not find the length for the singel data types')

finally:
    print("iam the final")