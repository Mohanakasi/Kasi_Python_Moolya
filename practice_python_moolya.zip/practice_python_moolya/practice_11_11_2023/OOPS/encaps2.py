# from encaps1 import bank_xyz
# class bank_xyz_ops(bank_xyz):
#     pass
#
# obj2 = bank_xyz_ops()
# print(bank_xyz._cc_num)
