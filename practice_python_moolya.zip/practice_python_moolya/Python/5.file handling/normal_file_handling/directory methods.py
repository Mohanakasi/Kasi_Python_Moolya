import os
print(os.getcwd())
os.chdir(r"C:\Users\Hp\PycharmProjects\python_training\venv")
print(os.getcwd())
print(os.listdir(r"C:\Users\Hp\PycharmProjects\python_training\3.comprehensions"))
print(os.path.getsize(r"C:\Users\Hp\PycharmProjects\python_training\file handling\csv_file handling\kasi_csv_file_practice.py"))
print(os.path.exists(r"C:\Users\Hp\PycharmProjects\python_training\file handling\csv_file handling\kasi_csv_file_practice.py"))
os.popen(r"C:\Users\Hp\PycharmProjects\python_training\my_files\kasi.csv")
