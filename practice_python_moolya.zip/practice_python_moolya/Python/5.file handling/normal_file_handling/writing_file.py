path = r"C:\Users\Hp\PycharmProjects\python_training\my_files\text files\kasi_temp_007.txt"
# with open(path, 'w') as file:
#     file.write("kasi new write\n")
#     file.write("line200\n")
#     file.write('line300\n')
#     file.writelines(['kasi\n','mohana\n'])

# with open(path, 'w') as file:
    # file.write("NAME: SETTIPALLI MOHANA KASIVISWESWARA RAO\n")
    # print(file.tell()) # tell gives the cursor position
    # file.write("age: 25\n")
    # print(file.tell())
    # file.write("sex: MALE\n")
    # print(file.tell())
    # file.write("mobile no: 8886213059\n")
    # file.write("address: guntur\n")
    # file.write("\n") # to make a line empty
    # file.writelines(["NAME: MOHANA","age: 25\n", "sex: MALE\n", "mobile no: 8886213059\n", "address: guntur\n"])
    # print(file.tell())

# with open(path) as file:
    # count = 0
    # for lineno,line in enumerate(file):
    #     count += len(line)
    # print(count)
    # file.seek(0)
    # print(file.readline())
    # file.seek(0)
    # print(file.readline(count)) # when we give more index no to input of readline it will print index upto one line onlyu
    # print(file.readlines())
    # file.seek(0)
    # print("")
    # list_ = file.readlines(count)
    # for l in list_:
    #     print(l)
    # print(file.read()) # reads data from starting to ending
    # file.seek(0)
    # print(file.readline())
    # file.seek(0)
    # for i in range(lineno):
    #     print(file.readline())
    # file.seek(0)
    # print(file.read(1))
    # for lineno,line in enumerate(file):
    #     pass
    # print(file.tell())
    # file.seek(0)
    # print(file.read)

# with open(path, 'a') as file:
#     file.write("Name: Rao")
import os
# print(os.mkdir(r"C:\Users\Hp\PycharmProjects\python_training\my_temp_dir") # if directory already exists it wil raise error
# print(os.listdir(r"C:\Users\Hp\PycharmProjects\python_training"))



