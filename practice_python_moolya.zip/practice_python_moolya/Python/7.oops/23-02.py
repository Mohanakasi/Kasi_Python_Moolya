"class decorators"

# class welcome:
#     def __init__(self, func):
#         self.func = func
#
#     def __call__(self, *args, **kwargs):
#         print(f"{self.func.__name__} is calling")
#         return self.func(*args, **kwargs)
#
# @welcome
# def upper(string_):
#     return string_.upper()
#
# print(upper('mohana kasi'))

# @welcome
# def Hdfc(name, type, balance):
#     print(f"name of the account holder: {name}")
#     print(f"account type: {type}")
#     print(f"Balance:{balance}")
#
# Hdfc('kasi','current account',-250000)

# @welcome
# def robo():
#     print("please lift the call")
#
# robo()

# l = [{'name': 'ram', 'class': 6, 'age': 12},
#      {'name': 'kasi', 'class': 10, 'age': 25},
#      {'name': 'raju', 'class':12, 'age': 30}]
#
#
# class custom_sort:
#     def __init(self, key):
#         self.key = key
#
#     def get_data(self, item):
#         if self.key == 'name'
#             return item['name']
#         elif self.key == 'class':
#             return item['class']
#         elif self.key == ['age']:
#             return item['age']


