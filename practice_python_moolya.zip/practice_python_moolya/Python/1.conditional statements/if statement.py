''' even or odd checking''''
#num=int(input("enter thr number to check"))
# if num%2==0:
#     print('even')

'''checking character cases'''
# chcecking character case
# ch = input("enter the char")
# if ch.islower():
#     print("the char {} is in lower case".format(ch))


'''checking element is present in collection'''
# list_ = ["hai","kasi","how"]
# element = "how"
# if element in list_:
#     print("the element {} is present in collection {}".format(element,list_))
